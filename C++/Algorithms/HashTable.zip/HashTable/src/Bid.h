/*
 * Bid.h
 *
 *  Created on: Jan 24, 2025
 *      Author: evannagy_snhu
 */

#ifndef BID_H_
#define BID_H_

#include <iostream>

class Bid {

public:
	Bid();
	virtual ~Bid();

	double getAmount() const;
	void setAmount(double amount);
	const std::string& getBidId() const;
	void setBidId(const std::string& bidId);
	const std::string& getFund() const;
	void setFund(const std::string& fund);
	const std::string& getTitle() const;
	void setTitle(const std::string& title);

	void display();

	std::string bidId; // unique identifier
		std::string title;
		std::string fund;
		double amount;



};

#endif /* BID_H_ */
