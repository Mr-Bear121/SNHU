/*
 * ALinkedList.h
 *
 *  Created on: Jan 24, 2025
 *      Author: evannagy_snhu
 */

#include <iostream>
#include <time.h>

#include "Bid.h"

//============================================================================
// Linked-List class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a linked-list.
 */

class ALinkedList {

public:
    ALinkedList();
	virtual ~ALinkedList();
	void Append(Bid bid);
	void Prepend(Bid bid);
	void PrintList();
	void Remove(std::string bidId);
	Bid Search(std::string bidId);
	int Size();

private:
	struct Node {
	        Bid bid;
	        Node *next;

	        // default constructor
	        Node() {
	            next = nullptr;
	        }

	        // initialize with a bid
	        Node(Bid aBid) {
	            bid = aBid;
	            next = nullptr;
	        }
	        };
	    	Node* head;
	    	Node* tail;
	    	int size = 0;

};

