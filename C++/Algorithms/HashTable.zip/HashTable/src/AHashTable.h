/*
 * AHashTable.h
 *
 *  Created on: Jan 28, 2025
 *      Author: evannagy_snhu
 */

#include <vector>
#include <ioStream>

/**
 * Define a class containing data members and methods to
 * implement a hash table with chaining.
 */

#include "Bid.h"
//#include "ALinkedList.h"
#include "CSVparser.hpp"


const unsigned int TABLE_DEFAULT_SIZE = 179;

using std::vector;
using std::string;

class AHashTable {
	unsigned int tableSize;

	//vector<ALinkedList*> hashTable;

public:
	AHashTable();
	virtual ~AHashTable();
	AHashTable(unsigned int size);
	unsigned int hash(int key);
	void Insert(Bid bid);
	void PrintAll();
	void Remove(std::string bidId);
	Bid Search(std::string bidId);
	size_t Size();

private:
	struct Node {
		        Bid bid;
		        Node *next;
		        unsigned key;

		        // default constructor
		        Node() {
		        	key = UINT_MAX;
		            next = nullptr;
		        }

		        // initialize with a bid
		        Node(Bid aBid) : Node(){
		            bid = aBid;
		            next = nullptr;
		        }
		        Node(Bid myBid, unsigned newKey) : Node(myBid) {
		                   key = newKey;
		               }
		        };
		    	int size = 0;
		    	vector<Node> myNodes;



};





