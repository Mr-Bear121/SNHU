/*
 * Bid.cpp
 *
 *  Created on: Jan 24, 2025
 *      Author: evannagy_snhu
 */

#include "Bid.h"
#include <string>

Bid::Bid() {
	// TODO Auto-generated constructor stub
	amount = 0.0;
}

Bid::~Bid() {
	// TODO Auto-generated destructor stub
}
double Bid::getAmount() const {
	return amount;
}

void Bid::setAmount(double amount) {
	this->amount = amount;
}

const std::string& Bid::getBidId() const {
	return bidId;
}

void Bid::setBidId(const std::string& bidId) {
	this->bidId = bidId;
}

const std::string& Bid::getFund() const {
	return fund;
}

void Bid::setFund(const std::string& fund) {
	this->fund = fund;
}

const std::string& Bid::getTitle() const {
	return title;
}

void Bid::setTitle(const std::string& title) {
	this->title = title;
}

void Bid::display() {
	std::cout << this->getBidId() << ": " << this->getTitle() << " | " << this->getAmount()
		<< " | " << this->getFund() << std::endl;
}


