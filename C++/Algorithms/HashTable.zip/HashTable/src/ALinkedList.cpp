/*
 * ALinkedList.cpp
 *
 *  Created on: Jan 24, 2025
 *      Author: evannagy_snhu
 */

#include "ALinkedList.h"
#include "Bid.h"
#include <string>

/**
 * Default constructor
 */
ALinkedList::ALinkedList() {
    // FIXME (1): Initialize housekeeping variables
    //set head and tail equal to nullptr
	head = nullptr;
	tail = nullptr;
}

/**
 * Destructor
 */
ALinkedList::~ALinkedList() {
    // start at the head
    Node* current = head;
    Node* temp;

    // loop over each node, detach from list then delete
    while (current != nullptr) {
        temp = current; // hang on to current node
        current = current->next; // make current the next node
        delete temp; // delete the orphan node
    }
}

/**
 * Append a new bid to the end of the list
 */
void ALinkedList::Append(Bid bid) {
    // FIXME (2): Implement append logic
    //Create new node
	Node* nNode = new Node(bid);
    //if there is nothing at the head...
	if(head == nullptr){
            // new node becomes the head and the tail
		head= nNode;
		tail= nNode;

    //else
	}else{
        // make current tail node point to the new node
		this->tail->next= nNode;
        // and tail becomes the new node
		this->tail= nNode;
    //increase size count
	this->size++;
	}
}

/**
 * Prepend a new bid to the start of the list
 */
void ALinkedList::Prepend(Bid bid) {
    // FIXME (3): Implement prepend logic
    // Create new node
	Node* nNode = new Node(bid);
    // if there is already something at the head...
	if(head != nullptr){
        // new node points to current head as its next node
		nNode->next = this->head;
    // head now becomes the new node
	head = nNode;
    //increase size count
	size++;
	}

}

/**
 * Simple output of all bids in the list
 */
void ALinkedList::PrintList() {
    // FIXME (4): Implement print logic
    // start at the head
	Node* currentNode = head;
    // while loop over each node looking for a match
	while(currentNode != nullptr){
        //output current bidID, title, amount and fund
        //set current equal to next
		//cout << currentNode->bid.getBid << std::endl;
		currentNode->bid.display();
		currentNode = currentNode->next;
	}
	return;
}

/**
 * Remove a specified bid
 *
 * @param bidId The bid id to remove from the list
 */
void ALinkedList::Remove(std::string bidId) {
    // FIXME (5): Implement remove logic
	Node* currentNode = head;

    // special case if matching node is the head
        // make head point to the next node in the list
        //decrease size count
        //return
	if(head->bid.getBidId() == bidId){
		head = head->next;
		size -= 1;
		std::cout << bidId << "  removed." << std::endl;
		return;
	}

    // start at the head
    // while loop over each node looking for a match
	while(currentNode->next != nullptr){
		// if the next node bidID is equal to the current bidID
		if(currentNode->next->bid.getBidId() == bidId){
			// hold onto the next node temporarily
			Node* tempNode = currentNode->next;
			// make current node point beyond the next node
			currentNode->next = tempNode->next;

			// now free up memory held by temp
			tempNode = nullptr;
			// decrease size count
			size -=1;
			std::cout << bidId << "  removed." << std::endl;
			//return
			return;
		}


    // current node is equal to next node
    currentNode = currentNode->next;
	}

}

/**
 * Search for the specified bidId
 *
 * @param bidId The bid id to search for
 */
Bid ALinkedList::Search(std::string bidId) {
    // FIXME (6): Implement search logic
	Node* currentNode = head;

    // special case if matching bid is the head
	if(head->bid.getBidId() == bidId){
		return currentNode->bid;
	}
    // start at the head of the list

    // keep searching until end reached with while loop (current != nullptr)
        // if the current node matches, return current bid
        // else current node is equal to next node
	while(currentNode != nullptr){
		if(currentNode->bid.getBidId() == bidId){
			return currentNode->bid;
		}
		currentNode = currentNode->next;
	}


    //(the next two statements will only execute if search item is not found)
        //create new empty bid
        //return empty bid
	return Bid();
}

/**
 * Returns the current size (number of elements) in the list
 */
int ALinkedList::Size() {
    return size;
}


