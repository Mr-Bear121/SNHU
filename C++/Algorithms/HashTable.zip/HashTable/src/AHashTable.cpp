/*
 * AHashTable.cpp
 *
 *  Created on: Jan 28, 2025
 *      Author: evannagy_snhu
 */

#include "AHashTable.h"
#include <string>

/**
 * Default constructor
 */
AHashTable::AHashTable() {

    tableSize = TABLE_DEFAULT_SIZE;
    // Initalize node structure by resizing tableSize
    myNodes.resize(tableSize);
}

/**
 * Constructor for specifying size of the table
 * Use to improve efficiency of hashing algorithm
 * by reducing collisions without wasting memory.
 */
AHashTable::AHashTable(unsigned int size) {
    // invoke local tableSize to size with this->
	this->tableSize = size;
    // resize nodes size
	myNodes.resize(tableSize);
}


/**
 * Destructor
 */
AHashTable::~AHashTable() {


    // erase nodes beginning
	myNodes.erase(myNodes.begin());
}

/**
 * Calculate the hash value of a given key.
 * Note that key is specifically defined as
 * unsigned int to prevent undefined results
 * of a negative list index.
 *
 * @param key The key to hash
 * @return The calculated hash
 */
unsigned int AHashTable::hash(int key) {

    // return key tableSize
	return key % tableSize ;
}

/**
 * Insert a bid
 *
 * @param bid The bid to insert
 */
void AHashTable::Insert(Bid bid) {

    // create the key for the given bid
	int key = this->hash(atoi(bid.bidId.c_str()));
    // retrieve node using key
	Node* currentNode = &(myNodes.at(key));

    // if no entry found for the key
	if(currentNode==nullptr){
        // assign this node to the key position
			Node* nodeUpdate = new Node(bid,key);
			this->myNodes.insert(myNodes.begin() + key, (*nodeUpdate));
		// else if node is not used
		}else {
			// assing old node key to UNIT_MAX, set to key, set old node to bid and old node next to null pointer
			if (currentNode->key == UINT_MAX) {
				currentNode->key = key;
				currentNode->bid = bid;
				currentNode->next = nullptr;
			           // else find the next open node
			       } else {

			           while (currentNode->next != nullptr) {
			        	   // add new newNode to end
			        	   currentNode = currentNode->next;
			           }
		}





}
}

/**
 * Print all bids
 */
void AHashTable::PrintAll() {

    // for node begin to end iterate
	for (unsigned int i = 0; i < myNodes.size(); ++i) {
	       std::cout << myNodes[i].bid.bidId << ": " << myNodes[i].bid.title << " | " << myNodes[i].bid.amount << " | "
	                   << myNodes[i].bid.fund << std::endl;
	   }
    //   if key not equal to UINT_MAx
            // output key, bidID, title, amount and fund
            // node is equal to next iter
            // while node not equal to nullptr
               // output key, bidID, title, amount and fund
               // node is equal to next node

}

/**
 * Remove a bid
 *
 * @param bidId The bid id to search for
 */
void AHashTable::Remove(string bidId) {

    // set key equal to hash atoi bidID cstring
	unsigned key = hash(atoi(bidId.c_str()));
    // erase node begin and key
	myNodes.erase(myNodes.begin() + key);
}

/**
 * Search for the specified bidId
 *
 * @param bidId The bid id to search for
 */
Bid AHashTable::Search(string bidId) {
    Bid bid;

    // FIXME (7): Implement logic to search for and return a bid

    // create the key for the given bid
    int key = this->hash(atoi(bid.bidId.c_str()));
    Node* mNode = &(this->myNodes.at(key));
    // if entry found for the key
    if(mNode != nullptr && mNode->key != UINT_MAX){
        //return node bid
    	return mNode->bid;
    }
    // if no entry found for the key
    if(mNode != nullptr && mNode->key != UINT_MAX
            && mNode->bid.bidId.compare(bidId) == 0){
    	// return bid
    	return bid;
    }


    // while node not equal to nullptr
    while(mNode != nullptr){
    	// if the current node matches, return it
    	if(mNode->key != UINT_MAX && mNode->bid.bidId.compare(bidId) == 0){
    		return mNode->bid;
    	}
    	//node is equal to next node
    	mNode = mNode->next;
    }

    return bid;
}

