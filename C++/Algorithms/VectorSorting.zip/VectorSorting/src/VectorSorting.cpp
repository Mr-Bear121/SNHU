//============================================================================
// Name        : VectorSorting.cpp
// Author      : Your name
// Version     : 1.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Vector Sorting Algorithms
//============================================================================


#include <algorithm>
#include <iostream>
#include <time.h>

#include "Bid.hpp"
#include "CSVparser.hpp"
#include "VectorSorting.hpp"

using namespace std;



/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        break;
    default:
    	// for some reason this file path wasnt working for me when trying to get the program to work.
    	// you may need to modify this in order to get the program to work
    	//csvPath = "eBid_Monthly_Sales.csv";
        csvPath = "U:/VectorSorting/src/eBid_Monthly_Sales.csv";
    }

    // Define a vector to hold all the bids
    vector<Bid> bids;

    // Define a timer variable
    clock_t ticks;

    bool isSorted;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Selection Sort All Bids" << endl;
        cout << "  4. Quick Sort All Bids" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;


        switch (choice) {

        case 1:
            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            bids = loadBids(csvPath);

            cout << bids.size() << " bids read" << endl;

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 2:
            // Loop and display the bids read
            for (int i = 0; i < bids.size(); ++i) {
                displayBid(bids[i]);
            }
            cout << endl;

            break;

        // FIXME (1b): Invoke the selection sort and report timing results
        case 3:
        	if(isSorted == true){

        		cout << "Please import the list again and then sort." << endl;
        		continue;
        	}
        	ticks = clock();

        	selectionSort(bids);

        	cout << bids.size() << "bids sorted " << endl;

        	ticks = clock() - ticks; // current clock ticks minus starting clock ticks
        	cout << "time: " << ticks << " clock ticks" << endl;
        	cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

        	isSorted = true;
        	break;

        // FIXME (2b): Invoke the quick sort and report timing results
        case 4:
        	if(isSorted == true){
        		cout << "Please import the list again and then sort." << endl;
                continue;
                }
            ticks = clock();

            quickSort(bids,0,bids.size()-1);

            cout << bids.size() << "bids sorted " << endl;

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            isSorted = true;
            break;

        }
    }

    cout << "Good bye." << endl;

    return 0;
}
