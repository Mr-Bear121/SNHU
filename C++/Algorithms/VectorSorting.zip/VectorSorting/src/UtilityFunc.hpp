/*
 * UtilityFunc.hpp
 *
 *  Created on: Jan 12, 2025
 *      Author: evannagy_snhu
 */

#ifndef UTILITYFUNC_HPP_
#define UTILITYFUNC_HPP_

#include <string>

using std::string;

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}


#endif /* UTILITYFUNC_HPP_ */
