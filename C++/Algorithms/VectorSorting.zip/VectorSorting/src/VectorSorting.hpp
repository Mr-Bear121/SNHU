/*
 * VectorSorting.hpp
 *
 *  Created on: Jan 12, 2025
 *      Author: evannagy_snhu
 */

#ifndef VECTORSORTING_HPP_
#define VECTORSORTING_HPP_

#include <algorithm>
#include <iostream>

#include "Bid.hpp"

// FIXME (2a): Implement the quick sort logic over bid.title

/**
 * Partition the vector of bids into two parts, low and high
 *
 * @param bids Address of the vector<Bid> instance to be partitioned
 * @param begin Beginning index to partition
 * @param end Ending index to partition
 */
int partition(vector<Bid>& bids, int begin, int end) {
    //set low and high equal to begin and end
	int high = end;
	int low = begin;

    // Calculate the middle element as middlePoint (int)
    // Set Pivot as middlePoint element title to compare (string)
	int middlePoint =(begin + end)/2;
	string pivot = bids.at(middlePoint).title;
    // while not done
	bool done = false;
	while(!done){
        // keep incrementing low index while bids[low].title < Pivot
		while(bids.at(low).title < pivot){
			low++;
		}
        // keep decrementing high index while Pivot < bids[high].title
		while(pivot < bids.at(high).title){
			high--;
		}


        /* If there are zero or one elements remaining,
            all bids are partitioned. Return high */
		if(low >= high){
			done = true;

       // else swap the low and high bids (built in vector method)
            // move low and high closer ++low, --high
		}else{
			swap(bids.at(low),bids.at(high));
			++low;
			--high;
		}

	}
    return high;
}

/**
 * Perform a quick sort on bid title
 * Average performance: O(n log(n))
 * Worst case performance O(n^2))
 *
 * @param bids address of the vector<Bid> instance to be sorted
 * @param begin the beginning index to sort on
 * @param end the ending index to sort on
 */
void quickSort(vector<Bid>& bids, int begin, int end) {
    //set mid equal to 0
	int mid = 0;

    /* Base case: If there are 1 or zero bids to sort,
     partition is already sorted otherwise if begin is greater
     than or equal to end then return*/
	if(begin >= end){

		return;
	}

    /* Partition bids into low and high such that
     midpoint is location of last element in low */
	mid = partition(bids,begin,end);
    // recursively sort low partition (begin to mid)
	quickSort(bids,begin,mid);
    // recursively sort high partition (mid+1 to end)
	quickSort(bids,mid+1,end);

	return;
}

// FIXME (1a): Implement the selection sort logic over bid.title

/**
 * Perform a selection sort on bid title
 * Average performance: O(n^2))
 * Worst case performance O(n^2))
 *
 * @param bid address of the vector<Bid>
 *            instance to be sorted
 */
void selectionSort(vector<Bid>& bids) {
    //define min as int (index of the current minimum bid)
	int min = 0;
    // check size of bids vector
    // set size_t platform-neutral result equal to bid.size()
	int size_t = bids.size();

    // pos is the position within bids that divides sorted/unsorted
    // for size_t pos = 0 and less than size -1
	for(int pos = 0; pos < size_t;pos++){
        // set min = pos
		min = pos;
        // loop over remaining elements to the right of position
		for(int p = pos + 1; p < size_t; p++){
            // if this element's title is less than minimum title
			if(bids.at(p).title.compare(bids.at(min).title) < 0){
                // this element becomes the minimum
				min = p;
		}
		}
		if (min != pos) {
					// swap the current minimum with smaller one found
					// swap is a built in vector method
					swap(bids.at(pos), bids.at(min));
				}
	}

}



#endif /* VECTORSORTING_HPP_ */
