//============================================================================
// Name        : CS-300.cpp
// Author      : Evan
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <string>
#include <time.h>
#include <Windows.h>
#include <vector>


using namespace std;
//will use this a default timer as to give the user a chance to see the result of the action.
const int GLOBAL_SLEEP_TIME = 5000;


//Course Data Structure
struct Course {
    string courseId;
    string courseName;
    vector<string> preList;
};

class BinarySearchTree{
private:
	struct Node{
		Course course;
		//right tree branch
		Node* right;
		//left tree branch
		Node* left;

		//default contructor
		Node(){
			left = nullptr;
			right = nullptr;
		}

		Node(Course mCourse){
			course = mCourse;
			left = nullptr;
			right = nullptr;
		}

	};
	Node* root;
	void inOrder(Node* node);
	int size = 0;
public:
	BinarySearchTree();
	void InOrder();
	void Insert(Course mCourse);
	void Remove(string courseId);
	Course Search(string courseId);
	int Size();

};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    this->root = nullptr;
}
void BinarySearchTree::InOrder(){
	inOrder(root);
}

void BinarySearchTree::Insert(Course mCourse){

	Node* currentNode = root;

	// if there is no root aka this is a new tree.
	if(root == NULL){
		//then add a node to the root and add a course to it.
		root = new Node(mCourse);
	}
	else{
		//else, while we have a node currently.
		while(currentNode != NULL){

			// if that node`s courseId is greater than our mCourse id.
			if(mCourse.courseId < currentNode->course.courseId){
				//and if there is no node in our left branch
				if(currentNode->left == nullptr){
					//add that course node to the left branch
					currentNode->left = new Node(mCourse);
					currentNode = NULL;
			}
				else{
					// else continue down the left branch
					currentNode = currentNode->left;
				}
		}
			else{
				// else our current courseId is less than mCourse id
				//and there is no node in our right branch
				if(currentNode->right == nullptr){
					// place a new course node in the right handed branch
					currentNode->right = new Node(mCourse);
					currentNode = NULL;
				}
				else{
					//else continue down the right side of the tree.
					currentNode = currentNode->right;
				}
			}
	}

}
	//after we have successfully inserted a node. Increase our tree size.
	size++;
}

void BinarySearchTree::Remove(string courseId){

	Node* parent = NULL;
	Node* current = root;

	while(current !=NULL){


		if(current->course.courseId==courseId){

			if(current->left == NULL && current->right == NULL){

				if(parent == NULL){
					root = nullptr;
				}

				else if(parent->left == current){

					parent->left = NULL;
				}

				else {
					parent->right = NULL;
				}
			}

			else if(current->right == NULL){

				if(parent == NULL){
					root = current->left;
				}

				else if(parent->left == current){
					parent->left = current->left;
				}

				else{
					parent->right = current->left;
				}

			} else if(current-> left == NULL){

				if(parent == NULL){
					root = current->right;
				} else if(parent->left == current){
					parent->left = current->right;
				}
				else{
					parent->right = current->right;
				}
			}

			else{

				Node* suc = current->right;

				while(suc->left !=NULL){
					suc = suc->left;
				}

				Node successorData = Node(suc->course);
				Remove(suc->course.courseId);
				current->course = successorData.course;
			}
			return;

		}

		else if (current->course.courseId < courseId) {
		            parent = current;
		            current = current->right;
		        }

		        else {
		            parent = current;
		            current = current->left;
		        }
		    }
		    cout << "\nValue not found" << endl;

	cout << "Value not found" << endl;
	return;
}

Course BinarySearchTree::Search(string courseId){
	// my course, mCourse
	Course mCourse;
	Node* currentNode = root;

	//while you you have a node
	while(currentNode != NULL){
		//if you find the correct id. return the course
		if(currentNode->course.courseId == courseId){
			return currentNode->course;
		}
		// else if your course id is less than the current nodes id.
		// search the left hand side of the tree
		else if(courseId < currentNode->course.courseId){
			currentNode = currentNode->left;

		}
		//else, it`s in the right hand side of the tree, look right.
		else{
			currentNode = currentNode->right;
		}
	}
	return mCourse;
}

void BinarySearchTree::inOrder(Node* node){

	if(node == NULL){
		//no node found
		return;
	}

	inOrder(node->left);

	//print the node
	cout << node->course.courseId << ", " << node->course.courseName << endl;

	inOrder(node->right);

}
int BinarySearchTree::Size() {

    return size;
}

vector<string> Split(string lineFeed){
	//character to split from out comma separated file "csv"
	// we will use this to know when to stop the split.
	char delimiter = ',';

	lineFeed += delimiter;
	vector<string> lineTokens;
	string temp = "";

	// for each letter in your line of characters.
	for(char letter : lineFeed){

		//if the end is not the delimiter, you are still parsing the word.
		if(letter == delimiter){
			lineTokens.push_back(temp);
			temp = "";
		}

		temp += letter;

	}

	return lineTokens;
}

void loadCourses(string csvPath,BinarySearchTree* courseList){

	    ifstream inFS; //instream to read file
	    string line; //line feed
	    // will use this to hold line items
	    vector<string> lineItems;

	    inFS.open(csvPath); //open the read file

	    if (!inFS.is_open()) {//small error handler
	        cout << "Could not open file. Please check inputs. " << endl;
	        return;
	    }

	    while (!inFS.eof()) {

	        Course mCourse;//create a new Course for each line

	        getline(inFS, line);
	        lineItems = Split(line); //split the line into tokens via the delimiter

	        /*
	         * if there aren't 2 tokens the line.
	         * then there is a formating mistake
	         */
	        if (lineItems.size() < 2) {

	            cout << "Error. Skipping line." << endl;
	        }

	        else {
	        	//assign appropriate values to the course object
	            mCourse.courseId = lineItems.at(0);
	            mCourse.courseName = lineItems.at(1);

	            for (unsigned int i = 2; i < lineItems.size(); i++) {

	            	mCourse.preList.push_back(lineItems.at(i));
	            }

	            // push this course to the end
	            courseList->Insert(mCourse);
	        }
	    }

	    inFS.close();
	}

void displayCourse(Course mCourse){

	cout<<mCourse.courseId << ", " << mCourse.courseName << endl;
	cout << "Prerequisites: ";

	if(mCourse.preList.empty()){
		cout << "None" << endl;
	}
	else{
		for(unsigned int i = 0; i < mCourse.preList.size(); i++){
			cout << mCourse.preList.at(i);
			//put a comma for any elements greater than 1
			if (mCourse.preList.size() > 1 && i < mCourse.preList.size() - 1) {
				cout << ", ";
			}
		}
	}
	cout << endl;
}

void DisplayMenu(){
	cout << "Menu: " << endl;
	cout << "1. Load Courses \n"
		<< "2. Display All Courses \n"
		<< "3. Find Course \n"
		<< "4. Remove Course \n"
		<<"9. Exit \n"
		<< "Enter Choice: ";
}

/*
Force the case of any string to uppercase
Pass the string by reference and change the case of any letter to upper
*/
void convertCase(string &toConvert) {

    for (unsigned int i = 0; i < toConvert.length(); i++) {
        if (isalpha(toConvert[i])) {
            toConvert[i] = toupper(toConvert[i]);
        }
    }
}

int main(int argc, char* argv[]) {

	//process command line arguments
	string csvPath,mCourseKey;

	switch(argc){

	case 2:
		csvPath = argv[1];
		break;

	case 3:
		csvPath = argv[1];
		mCourseKey = argv[2];
		break;

	default:
		//csvPath = "U:/CS-300 Final Project/src/FinalProject_Sample_input.csv";
		csvPath = "FinalProject_Sample_input.csv";
	}

	// instantiate a new table
	BinarySearchTree* courseList = new BinarySearchTree();

	Course course;
	// did we get an input? yes or no.
	bool input;
	int choice = 0;

	while(choice !=9){
		DisplayMenu();

		mCourseKey = "";
		string anyKey = " ";
		choice = 0;

		try{
			// get user choice.
			cin >> choice;
			cout << endl;

			// if the user choice is between 1 and 4 "or menu options" or is equal to our 9th option.
			if((choice > 0 && choice < 5) || (choice == 9)){
				//then we have a valid input.
				input = true;
			}
			else
			{
				//else we have an invalid input throw an error.
				input = false;
				throw 1;
			}

			//based on our user`s choice. do one of the following options.
			switch(choice){
			case 1:
				loadCourses(csvPath,courseList);
				cout << courseList->Size() << " courses read" << endl;
				break;

			case 2:
				courseList->InOrder();
				Sleep(3000);
				break;

			case 3:
				cout << "\n What course do you want to know about? " << endl;
				cin >> mCourseKey;

				convertCase(mCourseKey);

				course = courseList->Search(mCourseKey);

				if(!course.courseId.empty()){
					displayCourse(course);
				}
				else{
					cout << "\nCourse ID " << mCourseKey << " not found." << endl;
				}
				Sleep(GLOBAL_SLEEP_TIME);
				break;

			case 4:
				cout << "\nWhat course do you want to delete? " << endl;
				cin >> mCourseKey;
				convertCase(mCourseKey);
				courseList->Remove(mCourseKey);
				break;

			case 9:
				exit(0);
				break;
			default:
				throw 2;
		}
		}catch(int error){
			cout << "\n Please check your input." << endl;
			Sleep(GLOBAL_SLEEP_TIME);
		}


		//need to clear the cin operator
		cin.clear();
		cin.ignore();

		//clear the console
		system("cls");
		    }

	cout << "Good bye." << endl;

	Sleep(GLOBAL_SLEEP_TIME);

	return 0;
}
