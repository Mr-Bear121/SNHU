/*
 * Bid.h
 *
 *  Created on: Feb 5, 2025
 *      Author: evannagy_snhu
 */


#include <ioStream>


class Bid {
public:
	// define a structure to hold bid information
	    std::string bidId; // unique identifier
	    std::string title;
	    std::string fund;
	    double amount;
	    Bid() {
	        amount = 0.0;
	    }
};




