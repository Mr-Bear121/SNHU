/*
 * ABinarySearchTree.h
 *
 *  Created on: Feb 3, 2025
 *      Author: evannagy_snhu
 */

#include "Node.h"
#include "CSVparser.hpp"

#include <cstddef>

using namespace std;


class ABinarySearchTree {
public:
	ABinarySearchTree();
	virtual ~ABinarySearchTree();

    void InOrder();
    void PostOrder();
    void PreOrder();
    void Insert(Bid bid);
    void Remove(std::string bidId);
    Bid Search(std::string bidId);
private:
    Node* root;

    void addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    void postOrder(Node* node);
    void preOrder(Node* node);
    Node* removeNode(Node* node, std::string bidId);
};


