/*
 * Node.h
 *
 *  Created on: Feb 5, 2025
 *      Author: evannagy_snhu
 */


#include "Bid.h"


class Node {

public:
	// Internal structure for tree node
	Bid bid;
	Node *left;
	Node *right;
	std::string key() {
				return bid.bidId;
	}
	virtual ~Node(){
		delete left;
		delete right;


	}



	    // default constructor
	    Node() {
	        left = nullptr;
	        right = nullptr;
	    }

	    // initialize with a bid
	    Node(Bid aBid) :
	            Node() {
	        bid = aBid;
	    }

};


