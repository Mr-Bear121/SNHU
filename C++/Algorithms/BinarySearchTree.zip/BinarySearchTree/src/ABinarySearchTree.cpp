/*
 * ABinarySearchTree.cpp
 *
 *  Created on: Feb 3, 2025
 *      Author: evannagy_snhu
 */

#include "ABinarySearchTree.h"

//Globals

Node* minValueNode(Node* node);

/**
 * Default constructor
 */
ABinarySearchTree::ABinarySearchTree() {
    //root is equal to nullptr
	root = nullptr;
}

/**
 * Destructor
 */
ABinarySearchTree::~ABinarySearchTree() {
    // recurse from root deleting every node
	delete root;
}

Node* minValueNode(Node* node)
{
    Node* current = node;

    /* loop down to find the leftmost leaf */
    while (current && current->left != nullptr)
        current = current->left;

    return current;
}

/**
 * Traverse the tree in order
 */
void ABinarySearchTree::InOrder() {
    // call inOrder function and pass root
	inOrder(root);
}

/**
 * Traverse the tree in post-order
 */
void ABinarySearchTree::PostOrder() {
    // postOrder root
	postOrder(root);
}

/**
 * Traverse the tree in pre-order
 */
void ABinarySearchTree::PreOrder() {

    // preOrder root
	preOrder(root);
}



/**
 * Insert a bid
 */
void ABinarySearchTree::Insert(Bid bid) {
    // if root equarl to null ptr
	if(root==nullptr){
      // root is equal to new node bid
		root = new Node(bid);
    // else
	}else{
      // add Node root and bid
		addNode(root,bid);
	}
}

/**
 * Remove a bid
 */
void ABinarySearchTree::Remove(std::string bidId) {
    // remove node root bidID
	removeNode(root,bidId);
}

/**
 * Search for a bid
 */
Bid ABinarySearchTree::Search(std::string bidId) {

	int depth = 0;
    // set current node equal to root
    Node* currentNode = new Node();

    currentNode = this->root;
    // keep looping downwards until bottom reached or matching bidId found
    while(currentNode != NULL){
    	// if match found, return current bid
    	if(currentNode->key() == bidId){
    		return currentNode->bid;
    	}
    	// Shift pointer to left child.
    	else if(currentNode->key() > bidId){
    		currentNode = currentNode->left;
    	}
    	// Shift pointer to right child.
    	else{
    		currentNode = currentNode->right;
    	}
    }

    cout << "\n Data not found\n" << endl;
    return Bid();
}

/**
 * Add a bid to some node (recursive)
 *
 * @param node Current node in tree
 * @param bid Bid to be added
 */
void ABinarySearchTree::addNode(Node* node, Bid bid) {

    // if node is larger then add to left

        // if no left node
            // this node becomes left
        // else recurse down the left node
    // else
        // if no right node
            // this node becomes right
        //else
            // recurse down the left node
	if(node->bid.bidId.compare(bid.bidId) > 0){
		if(node->left == nullptr){
			node->left = new Node(bid);
		}else{
			this->addNode(node->left,bid);
		}

	}else{
		if(node->right == nullptr){
			node->right = new Node(bid);
		}else{
			this->addNode(node->right,bid);
		}
	}
}
void ABinarySearchTree::inOrder(Node* node) {

      //if node is not equal to null ptr
      //InOrder not left
      //output bidID, title, amount, fund
      //InOder right
	if(node!= nullptr){
		inOrder(node->left);
		std::cout << node->bid.bidId << ": " << node->bid.title << " | " << node->bid.amount << " | "
			            << node->bid.fund << std::endl;
		inOrder(node->right);
	}
}
void ABinarySearchTree::postOrder(Node* node) {

      //if node is not equal to null ptr
	if(node == nullptr){
			return;
		}
      //postOrder left
	postOrder(node->left);
      //postOrder right
	postOrder(node->right);
      //output bidID, title, amount, fund
	 cout << node->bid.bidId << " | " << node->bid.title << " | " << node->bid.amount << " | " << node->bid.fund;


}

void ABinarySearchTree::preOrder(Node* node) {

      //if node is not equal to null ptr
	if(node==nullptr){
		return;
	}
      //output bidID, title, amount, fund
	cout << node->bid.bidId << " | " << node->bid.title << " | " << node->bid.amount << " | " << node->bid.fund;
	//preOrder left
	preOrder(node->left);
	//preOrder right
	preOrder(node->right);
}

/**
 * Remove a bid from some node (recursive)
 */
Node* ABinarySearchTree::removeNode(Node* node, std::string bidId) {

    // if node = nullptr return node
	if(root==nullptr){
		return root;
	}
    // (otherwise recurse down the left subtree)
    // check for match and if so, remove left node using recursive call
	if(bidId.compare(node->bid.bidId) < 0){
		node->left = removeNode(node->left, bidId);

    // (otherwise recurse down the right subtree)
    // check for match and if so, remove right node using recursive call
	}else if(bidId.compare(node->bid.bidId) > 0){
		node->right = removeNode(node->right, bidId);

    // (otherwise no children so node is a leaf node)
    // if left node = nullptr && right node = nullptr delete node
	}else{
	    // (otherwise check one child to the left)
	    // if left node != nullptr && right node = nullptr delete node
		if (node->left == nullptr && node->right == nullptr){
			delete node;
			node = nullptr;
		}
	    // (otherwise check one child to the right)
	    // if left node = nullptr && right node != nullptr delete node
		else if (node->left != nullptr && node->right == nullptr) {
			Node* tempNode = node;
			node = node->left;
			delete tempNode;


	} else if (node->left == nullptr && node->right != nullptr) {
				Node* tempNode = node;
				node = node->right;
				delete tempNode;
			}
    // (otherwise more than one child so find the minimum)
	else{
	    // create temp node to right
		Node* temp = node->right;
		while(temp->left == nullptr) {
		    // while left node is not nullptr keep moving temp left
			temp = temp->left;
		}


	    // make node bid (right) equal to temp bid (left)
		node->bid = temp->bid;
	    // remove right node using recursive call
		node->right = removeNode(node->right, temp->bid.bidId);

	}
}
    // return node
	return root;
}


